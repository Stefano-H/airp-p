// public/script.js
document.getElementById('cargarDatos').addEventListener('click', () => {
    fetch('/api')
      .then(response => response.json())
      .then(data => {
        document.getElementById('respuesta').textContent = data.mensaje;
      })
      .catch(error => console.error('Error:', error));
  });
  