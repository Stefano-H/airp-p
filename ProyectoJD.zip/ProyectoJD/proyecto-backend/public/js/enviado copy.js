
function generarCodigoTicket(){
    // Define los caracteres posibles para las letras mayúsculas y los números
    const letrasMayusculas = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const numeros = '0123456789';
    
    let codigo = '';

    // Genera 3 letras mayúsculas aleatorias
    for (let i = 0; i < 3; i++) {
        const indiceAleatorio = Math.floor(Math.random() * letrasMayusculas.length);
        codigo += letrasMayusculas.charAt(indiceAleatorio);
    }

    // Genera 3 números aleatorios
    for (let i = 0; i < 3; i++) {
        const indiceAleatorio = Math.floor(Math.random() * numeros.length);
        codigo += numeros.charAt(indiceAleatorio);
    }

    return codigo;
}

function enviar(){
    var correo = document.getElementById('userGmail').value;
    if (correo.trim() === "") {
        Swal.fire({
            icon: "error",
            title: "Oops...",
            html: `
                
                <p style="border-radius: 10px;padding: 10px 50px;">Debes introducir un correo valido</p>
                `
          });
    }
    else{
    // Llama a la función para generar un código de ticket único con 3 letras y 3 números
    var codigoTicket = generarCodigoTicket();

    // Guarda el código de ticket en localStorage
    localStorage.setItem('codigoTicket', codigoTicket);



    Swal.fire({
        title: "Ticket Enviado con Éxito!",
        html: `
            <p class="text">Código del ticket enviado al siguiente correo:</p>
            <p style="border: 2px solid #000;border-radius: 10px;padding: 10px 50px;background-color: rgba(120, 121, 123, 0.5);">${correo}</p>
            <p class="text">Puede revisar el estado de la incidencia usando el siguiente código:</p>
            <p style="border: 2px solid #000;border-radius: 10px;padding: 10px 50px;background-color: rgba(120, 121, 123, 0.5);"  class="resaltado">#${codigoTicket}</p>
        `,
        showClass: {
            popup: `
                animate__animated
                animate__fadeInUp
                animate__faster
            `
        },
        hideClass: {
            popup: `
                animate__animated
                animate__fadeOutDown
                animate__faster
            `
        }
    });
    }
}

function verificar(){
    Swal.fire({
        icon: "error",
        title: "Oops...",
        html: `
            
            <p style="border-radius: 10px;padding: 10px 50px;">El codigo introducido no corresponde a ninguna incidencia existente</p>
            `
      });
}


// Función para verificar el código de ticket introducido en el campo de búsqueda
function verificarCodigoTicket(){
    var codigoIntroducido = document.getElementById('boxSearch').value;
    var codigoGenerado = localStorage.getItem('codigoTicket');

    if (codigoIntroducido === codigoGenerado) {
        // Si los códigos coinciden, redirige a la página de resultados
        window.location.href = './usuarioResultado.html';
    } else {
        // Si no coinciden, muestra un mensaje de error
        verificar();
        
    }
}

// Añadir evento para verificar el código cuando se presione el botón de búsqueda
document.getElementById('iconoSearch').addEventListener('click', function (e) {
    e.preventDefault(); // Prevenir la acción predeterminada del enlace
    verificarCodigoTicket();
});

