function mostrarSwal(buttonType, incidenciaId) {
    setTimeout(() => {
        let title = '';
        let text = '';
        let icon = 'info'; // Icono por defecto
        const incidencia = document.querySelector(`.incidencia[data-id="${incidenciaId}"]`);
        const estadoIncidencia = document.querySelector(`#estadoticket-${incidenciaId}`).innerText;

        // Verificar si la incidencia ya está en el panel "Incidencias en Proceso"
        const isInProgress = document.querySelector('.incidenciasenproceso-panel .scrollable').contains(incidencia);

        if (buttonType === 'tag') {
            title = 'Asigna una prioridad';
            text = 'Elige una de las siguientes opciones:';
            icon = 'question'; // Icono de pregunta

            // Si la incidencia ya está en "Incidencias en Proceso", solo permitir cambiar el estado
            if (isInProgress) {
                // Mostrar solo el estado para cambiar, sin opción de cambiar la prioridad
                Swal.fire({
                    title: 'Modificar Estado',
                    text: 'Selecciona el nuevo estado de la incidencia:',
                    icon: icon,
                    input: 'select',
                    inputOptions: {
                        'En progreso': 'En progreso',
                        'Pendiente': 'Pendiente',
                        'Resuelto': 'Resuelto',
                    },
                    inputPlaceholder: 'Selecciona un estado',
                    showCancelButton: true,
                    confirmButtonColor: "#3085d6",
                    cancelButtonColor: "#d33",
                    confirmButtonText: "Confirmar",
                    cancelButtonText: "Cancelar",
                    customClass: {
                        title: 'fuentejs',
                        content: 'fuentejs',
                        container: 'fuentejs',
                        confirmButton: 'fuentejs',
                        cancelButton: 'fuentejs'
                    }
                }).then((resultEstado) => {
                    if (resultEstado.isConfirmed && resultEstado.value) {
                        const estadoElemento = document.querySelector(`#estadoticket-${incidenciaId}`);
                        const estadoSeleccionado = resultEstado.value;

                        // Actualizar el contenido del estado de la incidencia seleccionada
                        estadoElemento.innerText = `Estado: ${estadoSeleccionado}`;

                        // Solo mover a "En Proceso" si el estado no es "Resuelto"
                        if (estadoSeleccionado == 'Resuelto') {
                            moverIncidencia(incidenciaId);
                        } else {
                            moveToInProgress(incidenciaId); 
                        }

                        // Mostrar alerta de éxito indicando que se ha actualizado el estado
                        if (estadoSeleccionado !== 'Resuelto') {
                            Swal.fire({
                                title: "Estado Actualizado",
                                text: `Estado: ${estadoSeleccionado}`,
                                icon: "success",
                                customClass: {
                                    title: 'fuentejs',
                                    content: 'fuentejs',
                                    container: 'fuentejs'
                                }
                            });
                        }
                    }
                });
            } else {
                // Mostrar un Swal con opción de cambiar prioridad y estado si la incidencia no está en "En Proceso"
                Swal.fire({
                    title: title,
                    text: text,
                    icon: icon,
                    input: 'select',
                    inputOptions: {
                        'Alta': 'Alta',
                        'Media': 'Media',
                        'Baja': 'Baja'
                    },
                    inputPlaceholder: 'Selecciona una prioridad',
                    showCancelButton: true,
                    confirmButtonColor: "#3085d6",
                    cancelButtonColor: "#d33",
                    confirmButtonText: "Confirmar",
                    cancelButtonText: "Cancelar",
                    customClass: {
                        title: 'fuentejs',
                        content: 'fuentejs',
                        container: 'fuentejs',
                        confirmButton: 'fuentejs',
                        cancelButton: 'fuentejs'
                    }
                }).then((result) => {
                    if (result.isConfirmed && result.value) {
                        const prioridadElemento = document.querySelector(`#prioridadSeleccionada-${incidenciaId}`);
                        const prioridadSeleccionada = result.value;

                        // Actualizar el contenido de la prioridad de la incidencia seleccionada
                        prioridadElemento.innerText = `Prioridad: ${prioridadSeleccionada}`;

                        // Cambiar el color de texto según la prioridad seleccionada
                        if (prioridadSeleccionada === 'Alta') {
                            prioridadElemento.style.color = 'red'; // Color rojo para Alta
                        } else if (prioridadSeleccionada === 'Media') {
                            prioridadElemento.style.color = 'orange'; // Color naranja para Media
                        } else if (prioridadSeleccionada === 'Baja') {
                            prioridadElemento.style.color = 'green'; // Color verde para Baja
                        }

                        // Mostrar un segundo Swal para seleccionar el estado
                        Swal.fire({
                            title: 'Asignar Estado',
                            text: 'Selecciona el estado de la incidencia:',
                            icon: 'question',
                            input: 'select',
                            inputOptions: {
                                'En progreso': 'En progreso',
                                'Pendiente': 'Pendiente',
                                'Resuelto': 'Resuelto',
                            },
                            inputPlaceholder: 'Selecciona un estado',
                            showCancelButton: true,
                            confirmButtonColor: "#3085d6",
                            cancelButtonColor: "#d33",
                            confirmButtonText: "Confirmar",
                            cancelButtonText: "Cancelar",
                            customClass: {
                                title: 'fuentejs',
                                content: 'fuentejs',
                                container: 'fuentejs',
                                confirmButton: 'fuentejs',
                                cancelButton: 'fuentejs'
                            }
                        }).then((resultEstado) => {
                            if (resultEstado.isConfirmed && resultEstado.value) {
                                const estadoElemento = document.querySelector(`#estadoticket-${incidenciaId}`);
                                const estadoSeleccionado = resultEstado.value;

                                // Actualizar el contenido del estado de la incidencia seleccionada
                                estadoElemento.innerText = `Estado: ${estadoSeleccionado}`;

                                // Solo mover a "En Proceso" si el estado no es "Resuelto"
                                if (estadoSeleccionado == 'Resuelto') {
                                    moverIncidencia(incidenciaId);
                                } else {
                                    moveToInProgress(incidenciaId); 
                                }

                                // Mostrar alerta de éxito SOLO si el estado no es "Resuelto"
                                if (estadoSeleccionado !== 'Resuelto') {
                                    Swal.fire({
                                        title: "Incidencia Actualizada",
                                        text: `Prioridad: ${prioridadSeleccionada} | Estado: ${estadoSeleccionado}`,
                                        icon: "success",
                                        customClass: {
                                            title: 'fuentejs',
                                            content: 'fuentejs',
                                            container: 'fuentejs'
                                        }
                                    });
                                }
                            }
                        });
                    }
                });
            }
            return; // Detener la ejecución aquí si se trata del caso 'tag'
        
        } else if (buttonType === 'trash') {
            // Bloque de confirmación para eliminar (botón "Eliminar")
            Swal.fire({
                title: "¿Estás seguro?",
                text: "¡No podrás revertir esto!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Sí, eliminarlo",
                cancelButtonText: "Cancelar",
                customClass: {
                    title: 'fuentejs',
                    content: 'fuentejs',
                    container: 'fuentejs',
                    confirmButton: 'fuentejs',
                    cancelButton: 'fuentejs'
                }
            }).then((result) => {
                if (result.isConfirmed && result.value) {
                    // Ejecutar la lógica de confirmación solo si se ha seleccionado algo
                    Swal.fire({
                        title: "¡Eliminado!",
                        text: "Tu archivo ha sido eliminado.",
                        icon: "success",
                        customClass: {
                            title: 'fuentejs',
                            content: 'fuentejs',
                            container: 'fuentejs'
                        }
                    });
                }
                // Si el usuario cancela, no hacer nada adicional.
            });
            return; // Detener la ejecución aquí si se trata del caso 'tag'
        }

        // Si no es un caso de eliminación, mostrar una alerta simple
        Swal.fire({
            title: title,
            text: text,
            icon: icon,
            customClass: {
                title: 'fuentejs',  // Aplica la clase a la fuente del título
                content: 'fuentejs', // Aplica la clase a la fuente del contenido
                container: 'fuentejs'
            }
        });
    }, 50); // Retraso de 50ms antes de mostrar la alerta
}


function moveToInProgress(incidenciaId) {
    const incidencia = document.querySelector(`.incidencia[data-id="${incidenciaId}"]`);
    const destino = document.querySelector('.incidenciasenproceso-panel .scrollable');
    
    // Mover la incidencia a "Incidencias en Proceso"
    destino.appendChild(incidencia);

    // Cambiar el color o añadir una clase a la incidencia para mostrar que está en proceso
    incidencia.classList.add('en-proceso');
    
    // Opcional: Deshabilitar el botón de "mover" o cambiarlo a un estado "moved"
    const btnTag = incidencia.querySelector('.btn-tag');
    btnTag.disabled = false;

    // Guardar el estado "En Proceso" en localStorage
    localStorage.setItem(incidenciaId, JSON.stringify({
        estado: 'En Proceso'
    }));
}

// Función para eliminar una incidencia
function eliminarIncidencia(incidenciaId) {
    // Confirma que el usuario quiere eliminar la incidencia
    Swal.fire({
        title: "¿Estás seguro?",
        text: "¡Esta acción eliminará la incidencia!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Sí, eliminar",
        cancelButtonText: "Cancelar",
        customClass: {
            title: 'fuentejs',
            content: 'fuentejs',
            container: 'fuentejs',
            confirmButton: 'fuentejs',
            cancelButton: 'fuentejs'
        }
    }).then((result) => {
        if (result.isConfirmed) {
            moverIncidencia(incidenciaId);  // Llamar a la función para mover la incidencia

            // // Buscar el contenedor de la incidencia con el ID
            // const incidencia = document.querySelector(`.incidencia[data-id="${incidenciaId}"]`);

            // // Si la incidencia existe, la elimina del DOM
            // if (incidencia) {
            //     incidencia.remove(); // Elimina el elemento del DOM
            //     Swal.fire({
            //         title: "¡Eliminado!",
            //         text: "La incidencia ha sido eliminada.",
            //         icon: "success",
            //         customClass: {
            //             title: 'fuentejs',
            //             content: 'fuentejs',
            //             container: 'fuentejs'
            //         }
            //     });
            // }
        }
    });
}

// Función para mover una incidencia a otro HTML en lugar de eliminarla
function moverIncidencia(incidenciaId) {
    // Encuentra la incidencia en el DOM
    const incidencia = document.querySelector(`.incidencia[data-id="${incidenciaId}"]`);
    
    // Guardar la incidencia en localStorage
    localStorage.setItem('incidencia_mover', incidencia.outerHTML);

    // Redirigir a otro archivo HTML donde se mostrará la incidencia movida
    window.location.href = './administradorHistorial.html';  // Reemplaza 'nuevoHTML.html' por el archivo donde deseas mostrar la incidencia
}

