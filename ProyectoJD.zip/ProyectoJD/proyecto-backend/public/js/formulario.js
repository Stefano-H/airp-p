document.getElementById('enviar').addEventListener('click', function() {
    // Ejecutar la función de enviar (puedes definirla en otro lugar)
    enviar(); 
    
    // Obtener el título del ticket
    var titulo = document.getElementById('boxTitle').value;
    
    // Guardar el título en localStorage
    localStorage.setItem('titulo', titulo);

    // Obtener los valores de los campos
    var nombre = document.getElementById('userInfo').value;
    var email = document.getElementById('userGmail').value;

    // Guardar los valores en localStorage
    localStorage.setItem('userInfo', nombre);
    localStorage.setItem('userGmail', email);


    var descriptionoriginal = document.getElementById('boxDescription').value;
    localStorage.setItem('boxDescription', descriptionoriginal);

    // alert('Título guardado!');
});