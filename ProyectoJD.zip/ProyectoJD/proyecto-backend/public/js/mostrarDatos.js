// Obtener los datos almacenados en localStorage
window.onload = function() {
    // Recuperar el título desde localStorage
    var titulo = localStorage.getItem('titulo');
    
    // Mostrar el título en un elemento de la página (por ejemplo, un div con id 'titulo')
    document.getElementById('titulo').textContent = titulo || 'No se ha ingresado un título';
}


