document.getElementById("download-btn").addEventListener("click", function() {
    downloadFile("file1.txt");
});

document.getElementById("download-btn-2").addEventListener("click", function() {
    downloadFile("file2.txt");
});

function downloadFile(filename) {
    const blob = new Blob([""], { type: "text/plain" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    link.click();
}

