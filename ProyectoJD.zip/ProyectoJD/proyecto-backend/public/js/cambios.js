

function respuestaEnviada() {

    Swal.fire({
        title: "Resolucion enviada con exito!",
        // text: "You clicked the button!",
        icon: "success"
      });
}