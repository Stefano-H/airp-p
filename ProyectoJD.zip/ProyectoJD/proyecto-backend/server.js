// MYSQL2 //

const mysql = require('mysql2');

const connection = mysql.createConnection({
    host: 'localhost',      // Cambiar según tu entorno
    user: 'root',           // Tu usuario de MySQL
    password: 'password',   // Tu contraseña de MySQL
    database: 'mi_base_de_datos' // Nombre de la base de datos
});

connection.connect((err) => {
    if (err) {
        console.error('Error conectando a la base de datos:', err);
        process.exit(1); // Detener el servidor si hay un error
    }
    console.log('Conexión exitosa a la base de datos');
});

module.exports = connection;

// MYSQL2 END //

const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Ruta para registrar incidencias
app.post('/crear-incidencia', (req, res) => {
    const nuevaIncidencia = {
        titulo: req.body.titulo,
        descripcion: req.body.descripcion,
        localizacion: req.body.localizacion,
        correo: req.body.correo,
        rol: req.body.rol,
        nombre: req.body.nombre,
        anonimo: req.body.anonimo,
        fecha: new Date().toISOString().slice(0, 19).replace('T', ' ')
    };

    // Consulta SQL para insertar
    connection.query('INSERT INTO incidencias SET ?', nuevaIncidencia, (err, results) => {
        if (err) {
            console.error('Error al registrar incidencia:', err);
            res.status(500).send('Error al registrar incidencia');
        } else {
            res.status(201).send({ mensaje: 'Incidencia registrada', id: results.insertId });
        }
    });
});

// Ruta para obtener incidencias
app.get('/obtener-incidencias', (req, res) => {
    connection.query('SELECT * FROM incidencias', (err, results) => {
        if (err) {
            console.error('Error al obtener incidencias:', err);
            res.status(500).send('Error al obtener incidencias');
        } else {
            res.status(200).send(results);
        }
    });
});

// Iniciar el servidor
const PORT = 3000;
app.listen(PORT, () => console.log(`Servidor corriendo en http://localhost:${PORT}`));

