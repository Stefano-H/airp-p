-- Crear la base de datos (si no lo has hecho aún)
CREATE DATABASE IF NOT EXISTS incidencias_db;

-- Seleccionar la base de datos para trabajar en ella
USE incidencias_db;

CREATE TABLE incidencias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(255) NOT NULL,
    descripcion TEXT NOT NULL,
    localizacion VARCHAR(100),
    correo VARCHAR(100),
    rol VARCHAR(50),
    nombre VARCHAR(100),
    anonimo BOOLEAN,
    fecha DATETIME
);

-- Crear la tabla de localizaciones
CREATE TABLE localizaciones (
    id_localizacion INT AUTO_INCREMENT PRIMARY KEY,
    nombre_localizacion VARCHAR(255) NOT NULL
);

-- Crear la tabla de roles
CREATE TABLE roles (
    id_rol INT AUTO_INCREMENT PRIMARY KEY,
    nombre_rol VARCHAR(50) NOT NULL
);

-- Crear la tabla de tickets
CREATE TABLE tickets (
    id_ticket INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(255) NOT NULL,
    descripcion TEXT NOT NULL,
    localizacion VARCHAR(255) NOT NULL,
    correo_creador VARCHAR(255) NOT NULL,
    rol_creador VARCHAR(50) NOT NULL,
    nombre_creador VARCHAR(255) NOT NULL,
    anonimo BOOLEAN NOT NULL,
    fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP,
    estado VARCHAR(50) DEFAULT 'abierto'
);

-- Crear la tabla de archivos
CREATE TABLE archivos (
    id_archivo INT AUTO_INCREMENT PRIMARY KEY,
    id_ticket INT,
    nombre_archivo VARCHAR(255) NOT NULL,
    ruta_archivo VARCHAR(255) NOT NULL,
    tipo_archivo VARCHAR(50),
    fecha_subida DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_ticket) REFERENCES tickets(id_ticket)
);

-- Insertar datos en la tabla de localizaciones
INSERT INTO localizaciones (nombre_localizacion) VALUES
('Urgencias'),
('Hospitalización'),
('Área cuidados intensivos'),
('Quirófano'),
('Área ginecología y obstetricia'),
('Hospital de dia'),
('Reanimación'),
('Consultas externas'),
('Otros');


-- Insertar datos en la tabla de roles
INSERT INTO roles (nombre_rol) VALUES
('Facultativo'),
('Enfermería'),
('Auxiliar'),
('Otro');

-- Verificar datos en la tabla de localizaciones
SELECT * FROM localizaciones;

-- Verificar datos en la tabla de roles
SELECT * FROM roles;